package finance

import (
	"copypaste.hk/platform/internal/fileref"
	"time"
)

type PaymentContent struct {
	Title              string           `json:"title"`
	Direction          *string          `json:"direction"`
	PaidAt             *string          `json:"paid_at"`
	Currency           *string          `json:"currency"`
	Amount             *string          `json:"amount"`
	Category           string           `json:"category"`
	Counterparty       *PartyRef        `json:"counterparty"`
	EmployeeID         *string          `json:"employee_id"`
	RefundOfID         *string          `json:"refund_of_id"`
	RefundFX           *PaymentRefundFX `json:"refund_fx,omitempty"`
	MethodLabel        string           `json:"method_label"`
	ExternalRef        string           `json:"external_ref"`
	EvidenceVersionIDs []string         `json:"evidence_version_ids"`
	Notes              string           `json:"notes"`
}
type PaymentCreate struct {
	PaymentContent
	SourceKey      string  `json:"source_key"`
	ProjectID      *string `json:"project_id"`
	Classification string  `json:"classification"`
	Reason         string  `json:"reason"`
}
type PaymentPatch struct {
	PaymentContent
	Base
}
type RefundAllocation struct {
	SourceAllocationID string  `json:"source_allocation_id"`
	Amount             string  `json:"amount"`
	CostAmount         *string `json:"cost_amount,omitempty"`
}
type PaymentRecordInput struct {
	Base
	ExpectedSourceVersion *int64             `json:"expected_source_version"`
	RefundAllocations     []RefundAllocation `json:"refund_allocations"`
	RefundFXAcknowledged  bool               `json:"refund_fx_acknowledged,omitempty"`
}
type PaymentReverseInput struct {
	Base
	EffectiveAt string `json:"effective_at"`
}
type PaymentAllocate struct {
	Base
	CostID          string          `json:"cost_id"`
	CostVersion     int64           `json:"cost_version"`
	CostRevisionID  string          `json:"cost_revision_id"`
	CostContentHash string          `json:"cost_content_hash"`
	Amount          string          `json:"amount"`
	ClaimID         *string         `json:"claim_id"`
	ClaimRevisionID *string         `json:"claim_revision_id"`
	ClaimLineID     *string         `json:"claim_line_id"`
	FX              *PaymentFXInput `json:"fx,omitempty"`
}
type PaymentRelease struct {
	Base
	Amount     string  `json:"amount"`
	CostAmount *string `json:"cost_amount,omitempty"`
}
type PaymentRefundAllocate struct {
	Base
	RefundAllocation
	RefundFXAcknowledged bool `json:"refund_fx_acknowledged,omitempty"`
}

// Amount/Shares in an allocation always conserve its original payment units.
// A foreign refund additionally conserves actual received cash in these fields.
type PaymentAllocationRefundCash struct {
	Amount           string       `json:"amount"`
	Currency         string       `json:"currency"`
	WholeAmount      string       `json:"whole_amount"`
	OriginalAmount   string       `json:"original_amount"`
	OriginalCurrency string       `json:"original_currency"`
	Rate             string       `json:"rate"`
	Source           string       `json:"source"`
	Shares           []Allocation `json:"shares"`
}
type PaymentAllocation struct {
	ID                  string                       `json:"id"`
	PaymentID           string                       `json:"payment_id"`
	CostID              string                       `json:"cost_id"`
	CostRevisionID      string                       `json:"cost_revision_id"`
	Kind                string                       `json:"kind"`
	Effect              int                          `json:"effect"`
	Amount              string                       `json:"amount"`
	RootID              string                       `json:"root_id"`
	SourceAllocationID  *string                      `json:"source_allocation_id"`
	ClaimID             *string                      `json:"claim_id"`
	ClaimRevisionID     *string                      `json:"claim_revision_id"`
	ClaimLineID         *string                      `json:"claim_line_id"`
	Shares              []Allocation                 `json:"shares"`
	RemainingAmount     string                       `json:"remaining_amount"`
	CostAmount          string                       `json:"cost_amount"`
	CostCurrency        string                       `json:"cost_currency"`
	PaymentCurrency     string                       `json:"payment_currency"`
	CostExponent        int                          `json:"cost_exponent"`
	PaymentExponent     int                          `json:"payment_exponent"`
	CostShares          []Allocation                 `json:"cost_shares"`
	RemainingCostAmount string                       `json:"remaining_cost_amount"`
	FX                  *PaymentFXQuote              `json:"fx"`
	RefundCash          *PaymentAllocationRefundCash `json:"refund_cash,omitempty"`
	ActorID             string                       `json:"actor_id"`
	Reason              string                       `json:"reason"`
	CreatedAt           time.Time                    `json:"created_at"`
}
type Payment struct {
	PaymentContent
	ID                           string             `json:"id"`
	Version                      int64              `json:"version"`
	SourceKey                    string             `json:"source_key"`
	ProjectID                    *string            `json:"project_id"`
	CreatorID                    string             `json:"creator_id"`
	Classification               string             `json:"classification"`
	RecordKind                   string             `json:"record_kind"`
	State                        string             `json:"state"`
	ReversesID                   *string            `json:"reverses_id"`
	ReversalID                   *string            `json:"reversal_id"`
	CurrentRevisionID            string             `json:"current_revision_id"`
	ContentHash                  string             `json:"content_hash"`
	PaidOn                       *string            `json:"paid_on"`
	CounterpartyEvidence         *PartyEvidence     `json:"counterparty_evidence"`
	Attachments                  []fileref.Evidence `json:"attachments"`
	EffectiveAllocatedAmount     string             `json:"effective_allocated_amount"`
	RefundedAmount               string             `json:"refunded_amount"`
	RefundAllocatedPrincipal     string             `json:"refund_allocated_principal"`
	ContractReturnReservedAmount string             `json:"contract_return_reserved_amount"`
	UnallocatedAmount            *string            `json:"unallocated_amount"`
	CanEdit                      bool               `json:"can_edit"`
	CanRecord                    bool               `json:"can_record"`
	CanAllocate                  bool               `json:"can_allocate"`
	CanReverse                   bool               `json:"can_reverse"`
	CreatedAt                    time.Time          `json:"created_at"`
	UpdatedAt                    time.Time          `json:"updated_at"`
}
type PaymentRevision struct {
	PaymentContent
	ID                   string             `json:"id"`
	Seq                  int64              `json:"seq"`
	BaseRevisionID       *string            `json:"base_revision_id"`
	ContentHash          string             `json:"content_hash"`
	AuthorID             string             `json:"author_id"`
	Reason               string             `json:"reason"`
	CreatedAt            time.Time          `json:"created_at"`
	CounterpartyEvidence *PartyEvidence     `json:"counterparty_evidence"`
	Attachments          []fileref.Evidence `json:"attachments"`
}
type PaymentEvent struct {
	Event
	AllocationID *string `json:"allocation_id"`
}
type ClaimSettlement struct {
	ClaimID           string  `json:"claim_id"`
	RevisionID        *string `json:"revision_id"`
	Currency          *string `json:"currency"`
	EligibleAmount    *string `json:"eligible_amount"`
	PaidAmount        *string `json:"paid_amount"`
	OutstandingAmount *string `json:"outstanding_amount"`
	State             *string `json:"state"`
	Visibility        string  `json:"visibility"`
}
type PaymentFilter struct {
	ProjectRecords                                                bool
	Query, State, Direction, Currency, Category, From, To, Cursor string
	ProjectID                                                     *string
	CompanyOnly                                                   bool
	Limit                                                         int
}
type CashTotal struct {
	Currency          string `json:"currency"`
	OutgoingAmount    string `json:"outgoing_amount"`
	RefundAmount      string `json:"refund_amount"`
	CorrectionAmount  string `json:"correction_amount"`
	NetAmount         string `json:"net_amount"`
	UnallocatedAmount string `json:"unallocated_amount"`
	EntryCount        int64  `json:"entry_count"`
}
type CashReport struct {
	Kind             string      `json:"kind"`
	From             string      `json:"from"`
	To               string      `json:"to"`
	Timezone         string      `json:"timezone"`
	AsOf             time.Time   `json:"as_of"`
	BaseCurrency     *string     `json:"base_currency"`
	FXCoverage       string      `json:"fx_coverage"`
	Totals           []CashTotal `json:"totals"`
	UnconfirmedCount int64       `json:"unconfirmed_count"`
}
