package finance

import (
	"context"
	"encoding/json"
	"slices"
	"strings"
	"time"

	"copypaste.hk/platform/internal/authz"
	"copypaste.hk/platform/internal/core"
	"copypaste.hk/platform/internal/identity"
	"copypaste.hk/platform/internal/platform"
	"github.com/jackc/pgx/v5"
)

// Every command uses project -> claim -> cost -> payment ordering. The same
// cost lock also serializes cost reversal and allocations from other payments.
func paymentProjectLocks(ctx context.Context, db platform.DBTX, a core.Actor, p Payment, extra []string, lock bool) error {
	ids := []string{}
	if p.ProjectID != nil {
		ids = append(ids, *p.ProjectID)
	}
	rows, err := db.Query(ctx, `SELECT DISTINCT cost_id::text FROM payment_allocations WHERE org_id=$1 AND payment_id IN ($2::uuid,$3::uuid)`, a.OrgID, p.ID, p.RefundOfID)
	if err != nil {
		return err
	}
	costs := append([]string{}, extra...)
	for rows.Next() {
		var id string
		if err = rows.Scan(&id); err != nil {
			rows.Close()
			return err
		}
		costs = append(costs, id)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return err
	}
	slices.Sort(costs)
	costs = slices.Compact(costs)
	for _, id := range costs {
		c, e := metadata(ctx, db, a.OrgID, id)
		if e != nil {
			return e
		}
		if e = readable(ctx, db, a, c, c.CurrentRevisionID); e != nil {
			return e
		}
		ids = append(ids, projectIDs(c, c.Content)...)
	}
	slices.Sort(ids)
	ids = slices.Compact(ids)
	for _, id := range ids {
		var state, class, owner string
		query := "SELECT state,classification,creator_id FROM projects WHERE org_id=$1 AND id=$2"
		if lock {
			query += " FOR UPDATE"
		}
		if err = db.QueryRow(ctx, query, a.OrgID, id).Scan(&state, &class, &owner); err != nil {
			return platform.DatabaseError(err)
		}
		if err = authz.Require(ctx, db, a, "project.read", authz.Resource{Type: "project", ID: id, ProjectID: &id, OwnerID: &owner, Classification: class}); err != nil {
			return err
		}
		var adequate bool
		if err = db.QueryRow(ctx, "SELECT classification_rank($1)<=classification_rank($2)", class, p.Classification).Scan(&adequate); err != nil {
			return err
		}
		if !adequate {
			return core.Invalid("classification", "资金分类不能低于关联项目")
		}
		if slices.Contains([]string{"closing", "archived", "cancelled"}, state) {
			return core.Fail(409, "PROJECT_READ_ONLY", "项目当前阶段不允许更改资金与结算记录")
		}
	}
	return nil
}

func lockPaymentRelated(ctx context.Context, tx pgx.Tx, a core.Actor, p Payment, extraCosts, extraClaims []string) error {
	if err := paymentProjectLocks(ctx, tx, a, p, extraCosts, true); err != nil {
		return err
	}
	rows, err := tx.Query(ctx, `SELECT DISTINCT cost_id::text,claim_id::text FROM payment_allocations WHERE org_id=$1 AND payment_id IN ($2::uuid,$3::uuid)`, a.OrgID, p.ID, p.RefundOfID)
	if err != nil {
		return err
	}
	costs := append([]string{}, extraCosts...)
	claims := append([]string{}, extraClaims...)
	for rows.Next() {
		var id string
		var claim *string
		if err = rows.Scan(&id, &claim); err != nil {
			rows.Close()
			return err
		}
		costs = append(costs, id)
		if claim != nil {
			claims = append(claims, *claim)
		}
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return err
	}
	slices.Sort(claims)
	claims = slices.Compact(claims)
	slices.Sort(costs)
	costs = slices.Compact(costs)
	for _, id := range claims {
		if _, err = tx.Exec(ctx, "SELECT id FROM spend_documents WHERE org_id=$1 AND id=$2 FOR UPDATE", a.OrgID, id); err != nil {
			return err
		}
	}
	for _, id := range costs {
		if _, err = tx.Exec(ctx, "SELECT id FROM actual_cost_entries WHERE org_id=$1 AND id=$2 FOR UPDATE", a.OrgID, id); err != nil {
			return err
		}
	}
	ids := []string{p.ID}
	if p.RefundOfID != nil {
		ids = append(ids, *p.RefundOfID)
	}
	slices.Sort(ids)
	ids = slices.Compact(ids)
	for _, id := range ids {
		if _, err = tx.Exec(ctx, "SELECT id FROM payment_records WHERE org_id=$1 AND id=$2 FOR UPDATE", a.OrgID, id); err != nil {
			return err
		}
	}
	return nil
}
func paymentEvent(ctx context.Context, tx pgx.Tx, a core.Actor, p Payment, kind, reason string, allocation *string) error {
	tag, err := tx.Exec(ctx, `INSERT INTO payment_events(id,org_id,payment_id,payment_version,revision_id,kind,state,allocation_id,actor_id,session_id,mfa_verified_at,reason)
        SELECT $1,$2,$3,$4,$5,$6,$7,$8,$9,s.id,s.mfa_verified_at,$10 FROM sessions s WHERE s.org_id=$2 AND s.id=$11 AND s.user_id=$9`, core.NewID(), a.OrgID, p.ID, p.Version, p.CurrentRevisionID, kind, p.State, allocation, a.UserID, reason, a.SessionID)
	if err == nil && tag.RowsAffected() != 1 {
		return core.Forbidden()
	}
	return err
}
func paymentResult(p Payment, kind, reason string, status int) core.Result {
	return core.Result{Status: status, Data: p, Event: core.Event{Type: "payment." + kind, ResourceType: "payment", ResourceID: p.ID, Version: p.Version, Payload: map[string]any{"reason": reason, "revision_id": p.CurrentRevisionID}}}
}
func (s *Service) paymentReplay(ctx context.Context, a core.Actor, out core.Result, err error) (core.Result, error) {
	if err != nil || !out.Replayed {
		return out, err
	}
	raw, e := json.Marshal(out.Data)
	if e != nil {
		return core.Result{}, e
	}
	var old Payment
	if e = json.Unmarshal(raw, &old); e != nil {
		return core.Result{}, e
	}
	current, e := s.Payment(ctx, a, old.ID)
	if e != nil {
		return core.Result{}, e
	}
	// The receipt keeps its original monetary snapshot. Mixing a cached head
	// with live allocations can falsely show a reversed payment as available.
	allocated, refunded, unallocated := old.EffectiveAllocatedAmount, old.RefundedAmount, old.UnallocatedAmount
	reserved := old.ContractReturnReservedAmount
	old, e = presentPayment(ctx, s.DB, a, old)
	if e != nil {
		return core.Result{}, e
	}
	old.EffectiveAllocatedAmount, old.RefundedAmount, old.UnallocatedAmount = allocated, refunded, unallocated
	old.ContractReturnReservedAmount = reserved
	if old.Version != current.Version {
		old.CanEdit = false
		old.CanRecord = false
		old.CanAllocate = false
		old.CanReverse = false
	}
	out.Data = old
	return out, nil
}
func (s *Service) CreatePayment(ctx context.Context, cmd core.Command, in PaymentCreate) (out core.Result, err error) {
	defer func() { out, err = s.paymentReplay(ctx, cmd.Actor, out, err) }()
	in.SourceKey = strings.TrimSpace(in.SourceKey)
	if !sourcePattern.MatchString(in.SourceKey) || strings.HasPrefix(in.SourceKey, "reversal:") || !core.Classification(in.Classification) || (in.ProjectID != nil && !core.ValidID(*in.ProjectID)) || (in.Classification == "project_restricted" && in.ProjectID == nil) || core.Name(in.Reason) != nil {
		return out, core.Invalid("source_key", "请提供永久资金来源标识、有效范围、分类与原因")
	}
	p := Payment{ID: core.NewID(), Version: 1, SourceKey: in.SourceKey, ProjectID: in.ProjectID, CreatorID: cmd.Actor.UserID, Classification: in.Classification, RecordKind: "payment", State: "draft", CurrentRevisionID: core.NewID()}
	authorize := func(tx pgx.Tx) error {
		if e := identity.RequireInteractiveSession(ctx, tx, cmd.Actor, false); e != nil {
			return e
		}
		for _, action := range []string{"payment.read", "payment.record"} {
			if e := authz.Require(ctx, tx, cmd.Actor, action, paymentResource(p)); e != nil {
				return e
			}
		}
		return nil
	}
	return s.Commands.Do(ctx, cmd, authorize, func(tx pgx.Tx) (core.Result, error) {
		content, e := normalizePayment(ctx, tx, in.PaymentContent, false)
		if e != nil {
			return core.Result{}, e
		}
		p.PaymentContent = content
		if e = paymentProjectLocks(ctx, tx, cmd.Actor, p, nil, true); e != nil {
			return core.Result{}, e
		}
		if _, e = paymentReferences(ctx, tx, cmd.Actor, p, content, true, false); e != nil {
			return core.Result{}, e
		}
		if p.EmployeeID != nil {
			var exists bool
			if e = tx.QueryRow(ctx, "SELECT EXISTS(SELECT 1 FROM users WHERE org_id=$1 AND id=$2 AND status='active')", cmd.Actor.OrgID, p.EmployeeID).Scan(&exists); e != nil {
				return core.Result{}, e
			}
			if !exists {
				return core.Result{}, core.Invalid("employee_id", "收款员工无效")
			}
		}
		if p.RefundOfID != nil {
			original, e := paymentMetadata(ctx, tx, cmd.Actor.OrgID, *p.RefundOfID)
			if e != nil {
				return core.Result{}, e
			}
			if e = paymentReadable(ctx, tx, cmd.Actor, original); e != nil {
				return core.Result{}, e
			}
			if original.RecordKind != "payment" || original.State != "recorded" || value(original.Direction) != "outgoing" {
				return core.Result{}, core.Fail(409, "REFUND_SOURCE_INVALID", "退款须引用未冲销的实际对外付款")
			}
		}
		if _, e = tx.Exec(ctx, `INSERT INTO payment_records(id,org_id,source_key,project_id,creator_id,classification,record_kind,state,current_revision_id) VALUES($1,$2,$3,$4,$5,$6,'payment','draft',$7)`, p.ID, cmd.Actor.OrgID, p.SourceKey, p.ProjectID, p.CreatorID, p.Classification, p.CurrentRevisionID); e != nil {
			return core.Result{}, e
		}
		if e = insertPaymentRevision(ctx, tx, cmd.Actor, p, p.CurrentRevisionID, 1, nil, content, in.Reason); e != nil {
			return core.Result{}, e
		}
		if e = paymentEvent(ctx, tx, cmd.Actor, p, "draft_created", in.Reason, nil); e != nil {
			return core.Result{}, e
		}
		p, e = paymentMetadata(ctx, tx, cmd.Actor.OrgID, p.ID)
		if e != nil {
			return core.Result{}, e
		}
		p, e = presentPayment(ctx, tx, cmd.Actor, p)
		return paymentResult(p, "draft.created", in.Reason, 201), e
	})
}
func (s *Service) mutatePayment(ctx context.Context, cmd core.Command, id, action string, base Base, mfa bool, costs, claims []string, fn func(pgx.Tx, Payment) (core.Result, error)) (out core.Result, err error) {
	defer func() { out, err = s.paymentReplay(ctx, cmd.Actor, out, err) }()
	if e := validBase(base); e != nil {
		return out, e
	}
	check := func(tx pgx.Tx) (Payment, error) {
		p, e := paymentMetadata(ctx, tx, cmd.Actor.OrgID, id)
		if e != nil {
			return p, e
		}
		if e = paymentReadable(ctx, tx, cmd.Actor, p); e != nil {
			return p, e
		}
		if e = authz.Require(ctx, tx, cmd.Actor, action, paymentResource(p)); e != nil {
			return p, e
		}
		return p, identity.RequireInteractiveSession(ctx, tx, cmd.Actor, mfa)
	}
	return s.Commands.Do(ctx, cmd, func(tx pgx.Tx) error { _, e := check(tx); return e }, func(tx pgx.Tx) (core.Result, error) {
		p, e := check(tx)
		if e != nil {
			return core.Result{}, e
		}
		if e = lockPaymentRelated(ctx, tx, cmd.Actor, p, costs, claims); e != nil {
			return core.Result{}, e
		}
		p, e = check(tx)
		if e != nil {
			return core.Result{}, e
		}
		if p.Version != base.ExpectedVersion || p.CurrentRevisionID != strings.ToLower(base.RevisionID) || p.ContentHash != base.ContentHash {
			return core.Result{}, core.Conflict()
		}
		before, _ := json.Marshal(p)
		out, e := fn(tx, p)
		out.Event.BeforeDigest = core.Digest(before)
		return out, e
	})
}
func (s *Service) finishPayment(ctx context.Context, tx pgx.Tx, a core.Actor, p Payment, kind, reason string, allocation *string) (core.Result, error) {
	p.Version++
	if _, err := tx.Exec(ctx, "UPDATE payment_records SET state=$3,current_revision_id=$4,version=version+1,updated_at=clock_timestamp() WHERE org_id=$1 AND id=$2", a.OrgID, p.ID, p.State, p.CurrentRevisionID); err != nil {
		return core.Result{}, err
	}
	if err := paymentEvent(ctx, tx, a, p, kind, reason, allocation); err != nil {
		return core.Result{}, err
	}
	p, err := paymentMetadata(ctx, tx, a.OrgID, p.ID)
	if err != nil {
		return core.Result{}, err
	}
	p, err = presentPayment(ctx, tx, a, p)
	return paymentResult(p, strings.ReplaceAll(kind, "_", "."), reason, 200), err
}
func (s *Service) UpdatePayment(ctx context.Context, cmd core.Command, id string, in PaymentPatch) (core.Result, error) {
	return s.mutatePayment(ctx, cmd, id, "payment.record", in.Base, false, nil, nil, func(tx pgx.Tx, p Payment) (core.Result, error) {
		if p.State != "draft" {
			return core.Result{}, core.Fail(409, "PAYMENT_IMMUTABLE", "已登记实际资金须通过冲销更正")
		}
		v, err := normalizePayment(ctx, tx, in.PaymentContent, false)
		if err != nil {
			return core.Result{}, err
		}
		// The original payment is part of the permanent draft identity. Changing
		// it would change the lock set after locks have already been acquired.
		if value(v.RefundOfID) != value(p.RefundOfID) {
			return core.Result{}, core.Invalid("refund_of_id", "退款原付款在建立草稿后固定，请另建正确草稿")
		}
		if _, err = paymentReferences(ctx, tx, cmd.Actor, p, v, true, false); err != nil {
			return core.Result{}, err
		}
		var seq int64
		if err = tx.QueryRow(ctx, "SELECT seq FROM payment_revisions WHERE org_id=$1 AND id=$2", cmd.Actor.OrgID, p.CurrentRevisionID).Scan(&seq); err != nil {
			return core.Result{}, err
		}
		next := core.NewID()
		if err = insertPaymentRevision(ctx, tx, cmd.Actor, p, next, seq+1, &p.CurrentRevisionID, v, in.Reason); err != nil {
			return core.Result{}, err
		}
		p.CurrentRevisionID = next
		return s.finishPayment(ctx, tx, cmd.Actor, p, "draft_revised", in.Reason, nil)
	})
}

func (s *Service) RecordPayment(ctx context.Context, cmd core.Command, id string, in PaymentRecordInput) (core.Result, error) {
	if len(in.RefundAllocations) > 100 {
		return core.Result{}, core.Invalid("refund_allocations", "一次最多引用100项退款分配")
	}
	costs, claims := []string{}, []string{}
	seen := map[string]bool{}
	for _, plan := range in.RefundAllocations {
		if !core.ValidID(plan.SourceAllocationID) || seen[plan.SourceAllocationID] {
			return core.Result{}, core.Invalid("refund_allocations", "退款分配来源无效或重复")
		}
		seen[plan.SourceAllocationID] = true
		source, err := allocationMetadata(ctx, s.DB, cmd.Actor.OrgID, plan.SourceAllocationID)
		if err != nil {
			return core.Result{}, err
		}
		costs = append(costs, source.CostID)
		if source.ClaimID != nil {
			claims = append(claims, *source.ClaimID)
		}
	}
	return s.mutatePayment(ctx, cmd, id, "payment.record", in.Base, true, costs, claims, func(tx pgx.Tx, p Payment) (core.Result, error) {
		if p.State != "draft" {
			return core.Result{}, core.Fail(409, "PAYMENT_NOT_DRAFT", "仅草稿可以登记为真实资金")
		}
		if _, err := normalizePayment(ctx, tx, p.PaymentContent, true); err != nil {
			return core.Result{}, err
		}
		if _, err := paymentReferences(ctx, tx, cmd.Actor, p, p.PaymentContent, true, true); err != nil {
			return core.Result{}, err
		}
		if value(p.Direction) == "refund" {
			original, err := paymentMetadata(ctx, tx, cmd.Actor.OrgID, value(p.RefundOfID))
			if err != nil {
				return core.Result{}, err
			}
			if err = paymentReadable(ctx, tx, cmd.Actor, original); err != nil {
				return core.Result{}, err
			}
			if original.State != "recorded" || original.RecordKind != "payment" || value(original.Direction) != "outgoing" || !samePaymentIdentity(p, original) || in.ExpectedSourceVersion == nil || *in.ExpectedSourceVersion != original.Version {
				return core.Result{}, core.Fail(409, "REFUND_SOURCE_CHANGED", "请重新核对未冲销原付款、收款人、币种、范围和版本")
			}
			paid, _ := time.Parse(time.RFC3339Nano, value(p.PaidAt))
			previous, _ := time.Parse(time.RFC3339Nano, value(original.PaidAt))
			if paid.Before(previous) {
				return core.Result{}, core.Invalid("paid_at", "退款时间不能早于原付款")
			}
			p.State = "recorded"
			for _, plan := range in.RefundAllocations {
				source, err := allocationMetadata(ctx, tx, cmd.Actor.OrgID, plan.SourceAllocationID)
				if err != nil {
					return core.Result{}, err
				}
				if _, err = s.inverseAllocation(ctx, tx, cmd.Actor, p, source, plan.Amount, "refund", in.Reason); err != nil {
					return core.Result{}, err
				}
			}
			if err = checkPaymentFunding(ctx, tx, cmd.Actor.OrgID, original, p); err != nil {
				return core.Result{}, err
			}
		} else if len(in.RefundAllocations) != 0 || in.ExpectedSourceVersion != nil {
			return core.Result{}, core.Invalid("refund_allocations", "仅退款登记可以指定原付款及退款分配")
		}
		p.State = "recorded"
		return s.finishPayment(ctx, tx, cmd.Actor, p, "recorded", in.Reason, nil)
	})
}

// A not-yet-recorded refund is included explicitly before its head transition.
func checkPaymentFunding(ctx context.Context, db platform.DBTX, org string, original Payment, pending Payment) error {
	if err := paymentBalances(ctx, db, org, &original); err != nil {
		return err
	}
	amount, _ := core.ParseDecimal(value(original.Amount))
	refunds, _ := core.ParseDecimal(original.RefundedAmount)
	allocated, _ := core.ParseDecimal(original.EffectiveAllocatedAmount)
	reserved, _ := core.ParseDecimal(original.ContractReturnReservedAmount)
	extra := core.Decimal{}
	if pending.ID != "" {
		extra, _ = core.ParseDecimal(value(pending.Amount))
	}
	if refunds.Add(extra).Cmp(amount) > 0 || allocated.Add(reserved).Cmp(amount.Sub(refunds).Sub(extra)) > 0 {
		return core.Fail(409, "PAYMENT_BALANCE_EXCEEDED", "退款或分配超过原付款当前可用余额，请同时释放相应费用分配")
	}
	return nil
}
