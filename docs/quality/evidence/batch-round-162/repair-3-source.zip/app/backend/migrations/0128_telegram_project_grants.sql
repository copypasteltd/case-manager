-- Expand only the existing exact project-update instruction protocol. All original evidence remains immutable.
CREATE OR REPLACE FUNCTION validate_telegram_write_grant() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE g telegram_write_grants;r agent_runs;m agent_run_mutations;
BEGIN
 IF TG_TABLE_NAME='telegram_write_grants' THEN g:=NEW;
 ELSE SELECT * INTO g FROM telegram_write_grants WHERE org_id=NEW.org_id AND id=NEW.grant_id;END IF;
 SELECT * INTO r FROM agent_runs WHERE org_id=g.org_id AND id=g.run_id;
 SELECT * INTO m FROM agent_run_mutations WHERE org_id=g.org_id AND run_id=g.run_id;
 IF r.id IS NULL OR r.channel<>'telegram' OR r.actor_id<>g.actor_id OR r.conversation_id<>g.conversation_id OR r.profile_id<>g.profile_id
 OR r.actor_auth_version<>g.actor_auth_version OR r.organization_auth_version<>g.organization_auth_version
 OR m.tool NOT IN ('submit_deliverable','update_task_dependency','create_task','create_risk','update_risk','create_issue','update_issue','create_deliverable','update_deliverable','create_milestone','update_project','update_task','transition_task','transition_project','update_milestone','transition_milestone')
 OR m.tool IS DISTINCT FROM (g.input::jsonb->'run'->'mutation'->>'tool') OR m.session_id IS DISTINCT FROM g.session_id
 OR (g.input::jsonb->'run'->'mutation'->'arguments') IS DISTINCT FROM m.arguments
 OR (g.input::jsonb->'run'->>'client_message_id') IS DISTINCT FROM r.client_message_id::text
 OR (g.input::jsonb->>'channel_id') IS DISTINCT FROM g.channel_id::text OR (g.input::jsonb->>'binding_id') IS DISTINCT FROM g.binding_id::text
 OR (g.input::jsonb->>'binding_version')::bigint IS DISTINCT FROM g.binding_version OR (g.input::jsonb->>'channel_version')::bigint IS DISTINCT FROM g.channel_version
  OR NOT EXISTS(SELECT 1 FROM sessions s WHERE s.org_id=g.org_id AND s.id=g.session_id AND s.user_id=g.actor_id AND s.device_type=g.origin_channel)
 THEN RAISE EXCEPTION 'TG grant requires an exact fixed project mutation and original human session' USING ERRCODE='23514';END IF;
 IF TG_TABLE_NAME='telegram_write_activations' THEN
 IF (NEW.run_id<>g.run_id OR g.expires_at<=clock_timestamp() OR r.state<>'queued' OR r.cancel_requested_at IS NOT NULL
 OR NOT EXISTS(SELECT 1 FROM telegram_inbox i JOIN telegram_channels ch ON ch.org_id=i.org_id AND ch.id=i.channel_id
 JOIN telegram_bindings b ON b.org_id=i.org_id AND b.id=i.binding_id WHERE i.org_id=NEW.org_id AND i.id=NEW.inbox_id
 AND i.requester_id=g.actor_id AND i.channel_id=g.channel_id AND i.channel_version=g.channel_version AND i.binding_id=g.binding_id
 AND i.actor_auth_version=g.actor_auth_version AND i.state='dispatched' AND ch.state='active' AND ch.version=g.channel_version
 AND ch.bot_id=i.bot_id AND ch.chat_id=i.chat_id AND ch.topic_id=i.topic_id AND b.state='active' AND b.telegram_user_id=i.telegram_user_id
 AND b.version=g.binding_version AND b.user_id=g.actor_id AND b.bot_id=ch.bot_id AND i.requested_skill_id='project-update'
 AND i.request_text ~ ('^/task(@[A-Za-z0-9_]+)?[[:space:]]+project-update[[:space:]]+authorize:'||g.id::text||'[[:space:]]*$'))) THEN
 RAISE EXCEPTION 'TG grant trigger is stale, reused or differs from its owner/group/input' USING ERRCODE='23514';END IF;
 END IF;
 RETURN NEW;
END;$$;

CREATE INDEX telegram_write_grants_owner_inventory ON telegram_write_grants(org_id,actor_id,created_at DESC,id DESC);

-- The immediate mutation guard must match the exact grant too.
CREATE OR REPLACE FUNCTION validate_agent_mutation_binding() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r agent_runs; m agent_run_mutations;
BEGIN
 SELECT * INTO r FROM agent_runs WHERE org_id=NEW.org_id AND id=NEW.run_id;
 IF TG_TABLE_NAME='agent_run_mutations' THEN
  IF r.id IS NULL OR r.actor_id<>NEW.actor_id OR r.conversation_id<>NEW.conversation_id OR r.state<>'queued'
   OR (((NEW.intent::jsonb)->>'actor_auth_version')::bigint=r.actor_auth_version
    AND ((NEW.intent::jsonb)->>'organization_auth_version')::bigint=r.organization_auth_version
    AND (NEW.intent::jsonb)->>'conversation_revision_id'=r.conversation_revision_id::text
    AND ((NEW.intent::jsonb)->>'context_security_version')::bigint=r.context_security_version) IS NOT TRUE
   OR (r.channel='telegram' AND NOT EXISTS(SELECT 1 FROM telegram_write_grants g WHERE g.org_id=r.org_id AND g.run_id=r.id AND g.session_id=NEW.session_id AND NEW.tool=(g.input::jsonb->'run'->'mutation'->>'tool') AND NEW.arguments=(g.input::jsonb->'run'->'mutation'->'arguments'))) OR r.cancel_requested_at IS NOT NULL OR NOT EXISTS(
    SELECT 1 FROM conversations c JOIN agent_runtime_profiles p ON p.org_id=c.org_id AND p.id=r.profile_id
    WHERE c.org_id=r.org_id AND c.id=r.conversation_id AND c.project_id=NEW.project_id
     AND c.current_revision_id=r.conversation_revision_id AND p.skill_id='project-update' AND p.state='active') THEN
   RAISE EXCEPTION 'mutation requires an exact sender, project conversation and queued update run' USING ERRCODE='23514';
  END IF;
 ELSE
  SELECT * INTO m FROM agent_run_mutations WHERE org_id=NEW.org_id AND run_id=NEW.run_id;
  IF m.run_id IS NULL OR r.state<>'running' OR r.cancel_requested_at IS NOT NULL OR r.expires_at<=clock_timestamp()
   OR (CASE WHEN m.tool='create_task' THEN
    (NEW.result_version=1 AND NEW.result_data->>'project_id'=m.project_id::text
     AND NEW.result_data->>'id'<>m.resource_id::text AND NEW.result_data->>'version'='1'
     AND NEW.result_data->>'state'='todo') IS NOT TRUE
    WHEN m.tool IN ('create_risk','create_issue') THEN
    (NEW.result_version=1 AND NEW.result_data->>'project_id'=m.project_id::text
     AND NEW.result_data->>'id'<>m.resource_id::text AND NEW.result_data->>'version'='1'
     AND NEW.result_data->>'state'='open') IS NOT TRUE
    WHEN m.tool='create_milestone' THEN
    (NEW.result_version=1 AND NEW.result_data->>'project_id'=m.project_id::text
     AND NEW.result_data->>'id'<>m.resource_id::text AND NEW.result_data->>'version'='1'
     AND NEW.result_data->>'state'='open') IS NOT TRUE
    WHEN m.tool='create_deliverable' THEN
    (NEW.result_version=1 AND NEW.result_data->>'id'<>m.resource_id::text
     AND NEW.result_data->>'version'='1' AND NEW.result_data->'revision_id'='null'::jsonb) IS NOT TRUE
    ELSE NEW.result_version<>m.base_version+1 OR (NEW.result_data->>'id'=m.resource_id::text
     AND (NEW.result_data->>'version')::bigint=NEW.result_version) IS NOT TRUE END) OR NOT EXISTS(
    SELECT 1 FROM idempotency_records i WHERE i.id=NEW.operation_id AND i.org_id=r.org_id AND i.actor_id=r.actor_id
    AND i.state='succeeded' AND i.route_key='/internal/agent-mutations/'||m.tool
    AND i.idempotency_key='agent-mutation:'||r.id::text AND i.response_data=NEW.result_data) THEN
   RAISE EXCEPTION 'mutation commit requires the exact successful versioned business command' USING ERRCODE='23514';
  END IF;
 END IF;
 RETURN NEW;
END; $$;
