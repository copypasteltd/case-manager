import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { chromium } from 'playwright';

const [url, output] = process.argv.slice(2);
assert.equal(new URL(url).origin, 'http://127.0.0.1:5189');
let browser, context;
const errors = [], checks = [];
const result = { passed: false, checks, context_closed: false, browser_closed: false, recorded_credentials: false, new_media: false };
try {
  browser = await chromium.launch({ headless: true });
  context = await browser.newContext({ viewport: { width: 430, height: 900 } });
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(url + '/#/pages/login/index', { waitUntil: 'domcontentloaded', timeout: 90000 });
  await page.getByPlaceholder('你的公司账号', { exact: true }).waitFor({ state: 'visible', timeout: 90000 });
  await page.getByText('仅限获授权的公司成员使用', { exact: true }).waitFor({ state: 'visible' });
  checks.push({ name: 'Current Taro watch output renders the ordinary login form', passed: true });
  assert.equal(await page.getByPlaceholder('输入密码', { exact: true }).inputValue(), '');
  checks.push({ name: 'No credential or business data is entered or recorded', passed: true });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.getByPlaceholder('你的公司账号', { exact: true }).waitFor({ state: 'visible' });
  assert.deepEqual(errors, []);
  checks.push({ name: 'Reload executes current bundles without page errors', passed: true });
  result.passed = true;
} catch (error) {
  result.error = String(error.message).slice(0, 1500);
} finally {
  if (context) {
    try { await context.close(); result.context_closed = true; } catch { result.context_closed = false; }
  }
  if (browser) {
    try { await browser.close(); result.browser_closed = !browser.isConnected(); } catch { result.browser_closed = false; }
  }
  result.passed = result.passed && result.context_closed && result.browser_closed;
  await writeFile(output, JSON.stringify(result, null, 2) + '\n');
}
console.log(JSON.stringify(result));
process.exitCode = result.passed ? 0 : 1;
